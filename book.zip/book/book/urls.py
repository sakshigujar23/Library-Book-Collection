from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home, name='home'),
    path('add_book/', views.add_book, name='add_book'),
    path('book_list/', views.book_list, name='book_list'),
    path('book_detail/', views.book_detail, name='book_detail'),
    path('book_update/', views.book_update, name='book_update'),
    path('book_delete/', views.book_delete, name='book_delete'),
]
