from django.shortcuts import render, redirect
from .models import Book

def home(request):
    context = {
        'Developer': 'Sakshi',
        'Company': 'Spider Projects One'
    }
    return render(request, "index.html", context)

def add_book(request):
    if request.method == "POST":
        title = request.POST.get("title")
        author = request.POST.get("author")
        genre = request.POST.get("genre")
        isbn = request.POST.get("isbn")
        pages = request.POST.get("pages")
        language = request.POST.get("language")
        publisher = request.POST.get("publisher")

        # Check if pages is not None before converting to int
        if pages is not None:
            pages = int(pages)

        book = Book()
        msg = book.create_book(title, author, genre, isbn, pages, language, publisher)
        return render(request, "book_add_status.html", {'status': msg})
    return render(request, "add_book.html")

def book_list(request):
    book = Book()
    books = book.get_all_books()
    return render(request, "book_list.html", {'books': books})

def book_detail(request):
    if request.method == "GET":
        title = request.GET.get("title")
        if title:
            book = Book().get_book_by_title(title)  # Instantiate Book class and call get_book_by_title method
            if book:
                return render(request, "book_detail.html", {'book': book})
            else:
                return render(request, "book_detail.html", {'error': 'Book not found'})
        else:
            return render(request, "book_detail.html", {'error': 'Please provide a book title'})
    else:
        return render(request, "book_detail.html", {'error': 'Invalid request method'})
    
# views.py
def book_update(request):
    if request.method == "POST":
        try:
            book_title = request.POST.get("title")  # Retrieve book title from POST data
            if book_title:
                book = Book()  # Instantiate the Book object
                book_data = {
                    'title': request.POST.get("title"),
                    'author': request.POST.get("author"),
                    'genre': request.POST.get("genre"),
                    'isbn': request.POST.get("isbn"),
                    'pages': int(request.POST.get("pages")),
                    'language': request.POST.get("language"),
                    'publisher': request.POST.get("publisher")
                }
                msg = book.update_book(book_title, book_data)
                return render(request, "book_update_status.html", {'status': msg})
            else:
                # If book title is not provided in the POST data, display an error message
                msg = "Please provide a book title."
                return render(request, "book_update_status.html", {'status': msg})
        except Exception as e:
            # If any exception occurs during the update process, display an error message
            msg = "An error occurred while updating the book."
            return render(request, "book_update_status.html", {'status': msg})
    return render(request, "book_update.html")


def book_delete(request):
    if request.method == "POST":
        book_title = request.POST.get("title")  # Retrieve book title from POST data
        book = Book()
        
        # Check if the book exists before attempting to delete it
        if book.get_book_by_title(book_title):
            msg = book.delete_book(book_title)
            return render(request, "book_delete_status.html", {'status': msg})

        else:
            msg = "Book with the provided title does not exist."
        
        return render(request, "book_delete_status.html", {'status': msg})
    
    return render(request, "book_delete.html")
