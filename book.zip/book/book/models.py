from pymongo import MongoClient

class Book:
    def __init__(self):
        # Connect to MongoDB
        self.client = MongoClient("mongodb+srv://sakshigujar2310:sakshi1822@cluster0.rkoahls.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

        self.db = self.client["gujardb"]
        self.books_collection = self.db["Books"]

    def create_book(self, title, author, genre, isbn, pages, language, publisher):
        try:
            self.books_collection.insert_one({
                'title': title,
                'author': author,
                'genre': genre,
                'isbn': isbn,
                'pages': pages,
                'language': language,
                'publisher': publisher
            })
            msg = "Book added successfully"
        except Exception as e:
            print(e)
            msg = "Failed to add book"
        return msg

    def get_all_books(self):
        return self.books_collection.find()

    def get_book_by_title(self, title):
         return self.books_collection.find_one({'title': title})

    def update_book(self, book_title, book_data):
        try:
            result = self.books_collection.update_one({'title': book_title}, {"$set": book_data})
            if result.modified_count == 1:
                # If one document was modified, return success message
                msg = "Book updated successfully"
            else:
               # If no document was modified (book not found), return error message
               msg = "Book not found or could not be updated"
        except Exception as e:
            print(e)
            msg = "Failed to update book"
        return msg


    def delete_book(self, book_title):
        try:
            self.books_collection.delete_one({'title': book_title})
            msg = "Book deleted successfully"
        except Exception as e:
            print(e)
            msg = "Failed to delete book"
        return msg
